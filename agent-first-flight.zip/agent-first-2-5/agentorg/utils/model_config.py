MODEL = {
    "model_type_or_path": "gpt-4o",
    "context": 16000,
    "max_tokens": 4096,
    "tokenizer": "o200k_base"
}