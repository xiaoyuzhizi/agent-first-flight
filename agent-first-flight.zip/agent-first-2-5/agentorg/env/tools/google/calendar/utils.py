AUTH_ERROR = "error: Google Calendar authentication failed"
