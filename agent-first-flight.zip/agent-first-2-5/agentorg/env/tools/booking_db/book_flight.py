from ..tools import register_tool
from .utils import *

import datetime
import uuid
import pandas as pd

@register_tool(
    "Books an existing flight",
    [{**SLOTS['Airline'], 'required': False}, 
     {**SLOTS['depart_airport'], 'required': False},
     {**SLOTS['arrive_airport'], 'required': False},
     {**SLOTS['depart_date'], 'required': False},
     {**SLOTS['depart_time'], 'required': False},
    ],
    [{
        "name": "query_result",
        "type": "str",
        "description": "A list of available flights that satisfies the given criteria (displays the first 10 results). If no flight satisfies the criteria, returns 'No flights exist'",
    }],
    lambda x: x and x not in (LOG_IN_FAILURE, NO_FLIGHT_MESSAGE, MULTIPLE_FLIGHTS_MESSAGE)
)
def book_flight(Airline=None, depart_airport=None, arrive_airport=None, depart_date=None, depart_time=None) -> str | None:
    if not log_in(): return LOG_IN_FAILURE
    
    logger.info("Enter book flight function")
    conn = sqlite3.connect(booking.db_path)
    cursor = conn.cursor()
    query = "SELECT Airline, depart_airport, arrive_airport, depart_date, depart_time, price, available_seats FROM flight WHERE 1 = 1"
    params = []
    slots = {"Airline": Airline, "depart_airport": depart_airport, "arrive_airport": arrive_airport, "depart_date": depart_date, "depart_time": depart_time}
    logger.info(f"{slots=}")
    for slot_name, slot_value in slots.items():
        if slot_value:
            query += f" AND {slot_name} = ?"
            params.append(slot_value)
            
    # Execute the query
    cursor.execute(query, params)
    rows = cursor.fetchall()
    logger.info(f"Rows found: {len(rows)}")
    
    response = None
    # Check whether info is enough to book a flight
    if len(rows) == 0:
        response = NO_FLIGHT_MESSAGE
    elif len(rows) > 1:
        response = MULTIPLE_FLIGHTS_MESSAGE
    else:
        column_names = [column[0] for column in cursor.description]
        results = dict(zip(column_names, rows[0]))
        flight_id = results["id"]

        # Insert a row into the booking table
        cursor.execute('''
            INSERT INTO booking (id, flight_id, user_id, created_at)
            VALUES (?, ?, ?, ?)
        ''', ("booking_" + str(uuid.uuid4()),  flight_id, booking.user_id, datetime.now()))

        results_df = pd.DataFrame([results])
        response = "The booked flight is:\n" + results_df.to_string(index=False)
        
    cursor.close()
    conn.close()
    return response