import sqlite3
import argparse
from pathlib import Path
import os


def build_database(folder_path):
    db_path = Path(folder_path) / "flight_booking_db.sqlite"
    if os.path.exists(db_path):
        os.remove(db_path)
    # Creating the database with a .sqlite extension
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Create tables based on the provided schema
    cursor.execute('''
        CREATE TABLE flight (
            id VARCHAR(40) PRIMARY KEY,
            Airline VARCHAR(100),
            depart_airport VARCHAR(100),
            arrive_airport VARCHAR(100),
            depart_date DATE,
            depart_time TIME,
            arrive_date DATE,
            arrive_time TIME,
            price DECIMAL,
            available_seats INTEGER
        )
    ''')


    cursor.execute('''
        CREATE TABLE user (
            id VARCHAR(40) PRIMARY KEY,
            first_name VARCHAR(40),
            last_name VARCHAR(40),
            email VARCHAR(60),
            register_at TIMESTAMP,
            last_login TIMESTAMP
        )
    ''')

    cursor.execute('''
        CREATE TABLE booking (
            id VARCHAR(40) PRIMARY KEY,
            flight_id VARCHAR(40),
            user_id VARCHAR(40),
            created_at TIMESTAMP,
            FOREIGN KEY (flight_id) REFERENCES flight(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
        )
    ''')

    # Populate sample data
    flights = [
        {
            "Airline": "Delta",
            "depart_airport": "PVG Shanghai Pudong",
            "arrive_airport": "JFK New York John F. Kennedy",
            "depart_date": "2025-2-11",
            "depart_time": "17:30:00",
            "arrive_date": "2025-2-11",
            "arrive_time": "23:13:00",
            "price": 456.0,
            "available_seats": 200,
            "id": "flight_8406f0c6-6644-4a19-9448-670c9941b8d8"
        },
        {
            "Airline": "Delta",
            "depart_airport": "PVG Shanghai Pudong",
            "arrive_airport": "JFK New York John F. Kennedy",
            "depart_date": "2025-2-11",
            "depart_time": "19:05:00",
            "arrive_date": "2025-2-12",
            "arrive_time": "6:28:00",
            "price": 456.0,
            "available_seats": 200,
            "id": "flight_06d03f1d-c38c-4ab2-b210-3342c76425f5"
        },
        {
            "Airline": "Delta",
            "depart_airport": "PVG Shanghai Pudong",
            "arrive_airport": "JFK New York John F. Kennedy",
            "depart_date": "2025-2-11",
            "depart_time": "19:05:00",
            "arrive_date": "2025-2-12",
            "arrive_time": "7:15:00",
            "price": 456.0,
            "available_seats": 150,
            "id": "flight_c32f2e1f-798a-406d-979b-733c2b37d90c"
        }

    ]


    users = [
        {
            "first_name": "Alice",
            "last_name": "Smith",
            "email": "alice.smith@gmail.com",
            "register_at": "2024-10-01 09:15:00",
            "last_login": "2024-10-12 08:30:00",
            "id": "user_be6e1836-8fe9-4938-b2d0-48f810648e72"
        },
        {
            "first_name": "Bob",
            "last_name": "Johnson",
            "email": "bob.johnson@gmail.com",
            "register_at": "2024-10-02 10:00:00",
            "last_login": "2024-10-13 07:45:00",
            "id": "user_ffd7218a-31c4-4377-902e-33faf36d168c"
        },
        {
            "first_name": "Carol",
            "last_name": "Williams",
            "email": "carol.williams@gmail.com",
            "register_at": "2024-10-03 11:30:00",
            "last_login": "2024-10-14 09:00:00",
            "id": "user_7404fbd7-d043-4d4c-80e6-28c9ae81dacc"
        },
        {
            "first_name": "David",
            "last_name": "Jones",
            "email": "david.jones@gmail.com",
            "register_at": "2024-10-04 12:00:00",
            "last_login": "2024-10-15 09:30:00",
            "id": "user_42f20628-1989-4d87-81e6-4f4faca63410"
        },
        {
            "first_name": "Eve",
            "last_name": "Brown",
            "email": "eve.brown@gmail.com",
            "register_at": "2024-10-05 13:45:00",
            "last_login": "2024-10-16 10:15:00",
            "id": "user_13074ec4-3813-4bbd-afa4-339e9eee27e9"
        }
    ]

    # Insert data into the database
    for flight in flights:
        columns = ', '.join(flight.keys())
        placeholders = ', '.join(['?'] * len(flight))
        values = tuple(flight.values())
        sql = f"INSERT INTO flight ({columns}) VALUES ({placeholders})"
        cursor.execute(sql, values)

    for user in users:
        columns = ', '.join(user.keys())
        placeholders = ', '.join(['?'] * len(user))
        values = tuple(user.values())
        sql = f"INSERT INTO user ({columns}) VALUES ({placeholders})"
        cursor.execute(sql, values)


    cursor.execute('''
        INSERT INTO booking (id, flight_id, user_id, created_at)
        VALUES
            ('1', 'flight_8406f0c6-6644-4a19-9448-670c9941b8d8', 'user_be6e1836-8fe9-4938-b2d0-48f810648e72', '2024-10-12 10:00:00')
    ''')

    # Commit changes and close the connection
    conn.commit()
    conn.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--folder_path", required=True, type=str, help="location to save the documents")
    args = parser.parse_args()

    if not os.path.exists(args.folder_path):
        os.makedirs(args.folder_path)

    build_database(args.folder_path)