import os
import sqlite3
import logging
from langchain_openai import ChatOpenAI

from agentorg.utils.model_config import MODEL

DBNAME = 'flight_booking_db.sqlite'
USER_ID = "user_be6e1836-8fe9-4938-b2d0-48f810648e72"

logger = logging.getLogger(__name__)

SLOTS = {
    "Airline": {
        "name": "Airline",
        "type": "string",
        "value": "",
        "description": "Name of the Airline",
        "prompt": "Please provide the name of the Airline"
    },
    "depart_airport": {
        "name": "depart_airport",
        "type": "string",
        "value": "",
        "description": "Departure Airport",
        "prompt": "Please provide the departure airport"
    },
    "arrive_airport": {
        "name": "arrive_airport",
        "type": "string",
        "value": "",
        "description": "Arrival Airport",
        "prompt": "Please provide the arrival airport"
    },
    "depart_date": {
        "name": "depart_date",
        "type": "date",
        "value": "",
        "description": "Date of departure",
        "prompt": "Please provide the date of departure"
    },
    "depart_time": {
        "name": "depart_time",
        "type": "time",
        "value": "",
        "description": "Time of departure",
        "prompt": "Please provide the time of departure"
    }
}

LOG_IN_FAILURE = "Failed to login. Please ensure user ID and database information is correct"
NO_FLIGHT_MESSAGE = "Flight is not found. Please check whether the information is correct."
MULTIPLE_FLIGHTS_MESSAGE = "There are multiple flights found. Please provide more details."
NO_BOOKING_MESSAGE = "You have not booked any flight."

class Booking:
    db_path = None
    llm = ChatOpenAI(model=MODEL["model_type_or_path"], timeout=30000)
    user_id = USER_ID
    # actions = {
    #     "SearchShow": "Search for shows", 
    #     "BookShow": "Book a show", 
    #     "CheckBooking": "Check details of booked show(s)",
    #     "CancelBooking": "Cancel a booking",
    #     "Others": "Other actions not mentioned above"
    # }

booking = Booking()

def log_in():
    booking.db_path = os.path.join(os.environ.get("DATA_DIR"), DBNAME)
    conn = sqlite3.connect(booking.db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT 1 FROM user WHERE id = ?", (booking.user_id,))
    result = cursor.fetchone()
    if result is None:
        logger.info(f"User {booking.user_id} not found in the database.")
    else:
        logger.info(f"User {booking.user_id} successfully logged in.")
    return result is not None